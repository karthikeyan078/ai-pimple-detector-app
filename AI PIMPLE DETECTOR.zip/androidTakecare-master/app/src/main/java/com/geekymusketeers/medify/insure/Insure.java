package com.geekymusketeers.medify.insure;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.TextureView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.content.res.AssetFileDescriptor;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.geekymusketeers.medify.R;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.tensorflow.lite.Interpreter;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Objects;

public class Insure extends AppCompatActivity {

    private static final int REQUEST_CAMERA_PERMISSION = 200;
    private Interpreter tflite; // TensorFlow Lite interpreter
    private CameraHelper cameraHelper;
    private int detectedFaces = 0;
    private TextView resultTextView;
    private Button captureButton;

    private ImageView selectedImageView;
    private TextView acneLevelTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide the title bar and set full screen
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Objects.requireNonNull(getSupportActionBar()).hide();
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }


        setContentView(R.layout.activity_insurance);


        // Load the TensorFlow Lite model
        try {
            tflite = new Interpreter(Objects.requireNonNull(loadModelFile())); // Implement the method to load the model file
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Set up the camera preview
        TextureView textureView = findViewById(R.id.textureView);
        cameraHelper = new CameraHelper(this, textureView);


        selectedImageView = findViewById(R.id.selectedImageView);
        acneLevelTextView = findViewById(R.id.acneLevelTextView);

        // Initialize UI elements
        resultTextView = findViewById(R.id.resultTextView);
        Button captureButton = findViewById(R.id.captureButton);
        captureButton.setOnClickListener(this::onCaptureClicked);
        textureView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(@NonNull SurfaceTexture surface, int width, int height) {
                openCamera(); // Initialize and open the camera
            }

            @Override
            public void onSurfaceTextureSizeChanged(@NonNull SurfaceTexture surface, int width, int height) {
                // Configure the transformation matrix
            }

            @Override
            public boolean onSurfaceTextureDestroyed(@NonNull SurfaceTexture surface) {
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(@NonNull SurfaceTexture surface) {
                // Update your frame
            }
        });
    }

    private void openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        } else {
            cameraHelper.openCamera();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            }
        }
    }



    private MappedByteBuffer loadModelFile() {
        try {
            AssetFileDescriptor fileDescriptor = getAssets().openFd("model_quantized.tf-lite");
            FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
            FileChannel fileChannel = inputStream.getChannel();
            long startOffset = fileDescriptor.getStartOffset();
            long declaredLength = fileDescriptor.getDeclaredLength();
            return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (cameraHelper != null) {
            cameraHelper.startBackgroundThread();
        }
    }

    public void onCaptureClicked(View view) {
        // Capture frame or process the current frame
        Bitmap currentFrame = cameraHelper.captureCurrentFrame();
        if (currentFrame != null) {
            processCameraFrame(currentFrame);
        }
    }

    // Method to process camera frames using the loaded model
    @SuppressLint("SetTextI18n")
    private void processCameraFrame(Bitmap image) {
        // Perform inference using the TensorFlow Lite model
        // Convert image to the format expected by the model
        // Process the inference results

        // For demonstration purposes, increment the face count
        detectedFaces++;
        runOnUiThread(() -> resultTextView.setText("Detected Faces: " + detectedFaces));
    }

    // Method to handle image selection button click
    public void onSelectImageClicked(View view) {
        Intent pickPhoto = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pickPhoto, 1);
    }

    // After picking an image, handle the result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                // Get the selected image URI
                Uri selectedImage = data.getData();
                if (selectedImage != null) {
                    selectedImageView.setImageURI(selectedImage);

                    try {
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                        processSelectedImage(bitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    // Method to process the selected image for acne detection
    private void processSelectedImage(Bitmap image) {
        // Perform acne detection on the selected image
        int acneLevel = performAcneDetection(image); // Method for acne detection
        displayAcneLevel(acneLevel);
    }

    // Method to display the acne level detected
    @SuppressLint("SetTextI18n")
    private void displayAcneLevel(int acneLevel) {
        acneLevelTextView.setText("Acne Level: " + acneLevel);
    }

    // Method for acne detection - Implement this based on your acne detection algorithm
    private int acneLevel = 3;

    // Perform acne detection using the provided image
    private int performAcneDetection(Bitmap image) {
        // For demonstration purposes, return an increasing acne level (3, 5, 7) and cap it at 7

        int currentAcneLevel = acneLevel;
        acneLevel += 2; // Increment acne level for the next call

        if (acneLevel > 7) {
            acneLevel = currentAcneLevel; // Cap the acne level at 7
        }

        return currentAcneLevel;
    }



    private String getSkinCondition(int acneLevel) {
        if (acneLevel <= 3) {
            return "Good skin";
        } else {
            return "Bad skin";
        }
    }

    @Override
    protected void onPause() {
        if (cameraHelper != null) {
            cameraHelper.stopBackgroundThread();
        }
        super.onPause();
    }
}
